#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/msg/robot_status.hpp"
#include "example_interfaces/srv/move_robot.hpp"
#include <thread>

class Robot
{
public:
    float move_distance(float distance)
    {
        status_ = example_interfaces::msg::RobotStatus::STATUS_MOVEING;
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        current_pose_ += distance;
        status_ = example_interfaces::msg::RobotStatus::STATUS_STOP;
        return current_pose_;
    }
    float get_current_pose() const { return current_pose_; }
    uint32_t get_status() const { return status_; }
private:
    float current_pose_ = 0.0f;
    uint32_t status_ = example_interfaces::msg::RobotStatus::STATUS_STOP;
};

class ExampleInterfacesRobot01 : public rclcpp::Node
{
public:
    explicit ExampleInterfacesRobot01(const std::string &name) : Node(name)
    {
        move_robot_service_ = create_service<example_interfaces::srv::MoveRobot>(
            "move_robot",
            [this](const std::shared_ptr<example_interfaces::srv::MoveRobot::Request> request,
                   std::shared_ptr<example_interfaces::srv::MoveRobot::Response> response) {
                RCLCPP_INFO(get_logger(), "收到移动请求: distance=%.2f", request->distance);
                response->pose = robot_.move_distance(request->distance);
                RCLCPP_INFO(get_logger(), "移动完成: pose=%.2f", response->pose);
            });
        robot_status_publisher_ = create_publisher<example_interfaces::msg::RobotStatus>("robot_status", 10);
        timer_ = create_wall_timer(std::chrono::seconds(1), [this]() {
            example_interfaces::msg::RobotStatus message;
            message.status = robot_.get_status();
            message.pose = robot_.get_current_pose();
            robot_status_publisher_->publish(message);
        });
        RCLCPP_INFO(get_logger(), "机器人节点已启动.");
    }
private:
    Robot robot_;
    rclcpp::Service<example_interfaces::srv::MoveRobot>::SharedPtr move_robot_service_;
    rclcpp::Publisher<example_interfaces::msg::RobotStatus>::SharedPtr robot_status_publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<ExampleInterfacesRobot01>("example_interfaces_robot_01");
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
