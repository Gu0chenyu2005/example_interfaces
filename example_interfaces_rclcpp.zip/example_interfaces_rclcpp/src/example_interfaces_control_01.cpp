#include "rclcpp/rclcpp.hpp"

class ExampleInterfacesControl01 : public rclcpp::Node
{
public:
    ExampleInterfacesControl01(std::string node_name) : Node(node_name)
    {
        RCLCPP_INFO(this->get_logger(), "控制节点已启动.");
    }   
// 创建服务客户端对象
    rclcpp::Client<example_interfaces::srv::MoveRobot>::SharedPtr client_;
client_= this->create_client<example_interfaces::srv::MoveRobot>("move_robot");
//创建订阅
robot_status_subscriber_ = this->create_subscription<example_interfaces::msg::RobotStatus>(
        "robot_status",
        10,
        std::bind(&ExampleInterfacesControl01::robot_status_callback, this, std::placeholders::_1));
 
        /**
   * @brief 发送移动机器人请求函数
   * 步骤：1.等待服务上线
   *      2.构造发送请求
   * 
   * @param distance 
   */

void move_robot(float distance) {
    // 等待服务上线
    while (!client_->wait_for_service(std::chrono::seconds(1))) {
        if (!rclcpp::ok()) {
            RCLCPP_ERROR(this->get_logger(), "客户端节点已关闭.");
            return;
        }
        RCLCPP_INFO(this->get_logger(), "等待服务端节点启动...");
    }
    // 构造发送请求
    auto request = std::make_shared<example_interfaces::srv::MoveRobot::Request>();
    request->distance = distance;
    auto result_future = client_->async_send_request(request);
    try {
        auto result = result_future.get();
        RCLCPP_INFO(this->get_logger(), "请求结果: %.2f", result->new_pose);
    } catch (const std::exception &e) {
        RCLCPP_ERROR(this->get_logger(), "服务调用失败: %s", e.what());
    }
}
auto request = std::make_shared<example_interfaces::srv::MoveRobot::Request>();
request->distance = distance;
auto result_future = client_->async_send_request(request);
try {
    auto result = result_future.get();
    RCLCPP_INFO(this->get_logger(), "请求结果: %.2f", result->new_pose);
} catch (const std::exception &e) {
    RCLCPP_ERROR(this->get_logger(), "服务调用失败: %s", e.what());
}
private:
rclcpp::Client<example_interfaces::srv::MoveRobot>::SharedPtr client_;
rclcpp::Subscription<example_interfaces::msg::RobotStatus>::SharedPtr robot_status_subscriber_;
void robot_status_callback(const example_interfaces::msg::RobotStatus::SharedPtr msg) {
    RCLCPP_INFO(this->get_logger(), "机器人状态: %d", msg->status);
    RCLCPP_INFO(this->get_logger(), "机器人位姿: %.2f", msg->pose); 
};      



int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<ExampleInterfacesControl01>("example_interfaces_control_01");
    node->move_robot(5.0f); // 发送移动请求，移动距离为5.0
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}

