#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/srv/add_two_ints.hpp"
// 创建服务服务端节点类
class ServiceServer01 : public rclcpp::Node
{
public:
ServiceServer01(std::string node_name) : Node(node_name)
{
    RCLCPP_INFO(this->get_logger(), "服务端节点已启动.");
    // 在构造函数中创建服务对象，并定义回调函数
    service_ = this->create_service<example_interfaces::srv::AddTwoInts>(
        "add_two_ints",
        [](const std::shared_ptr<example_interfaces::srv::AddTwoInts::Request> request,
           std::shared_ptr<example_interfaces::srv::AddTwoInts::Response> response) {
            response->sum = request->a + request->b;
        });
}
private:
rclcpp::Service<example_interfaces::srv::AddTwoInts>::SharedPtr service_;
};
// 主函数
int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<ServiceServer01>("service_server_01");
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
