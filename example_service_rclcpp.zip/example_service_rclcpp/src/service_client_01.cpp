#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/srv/add_two_ints.hpp"
#include <thread>
// 创建服务客户端节点类
class ServiceClient01 : public rclcpp::Node
{
public:
    ServiceClient01(std::string node_name) : Node(node_name)
    {
        // 输出日志信息，表示客户端节点已启动
        RCLCPP_INFO(this->get_logger(), "客户端节点已启动.");
        add_ints_server_ = this->create_client<example_interfaces::srv::AddTwoInts>("add_two_ints");
        // 创建一个线程，等待服务端节点启动并发送请求
        std::thread([this]() {
            while (!add_ints_server_->wait_for_service(std::chrono::seconds(1))) {
                if (!rclcpp::ok()) {
                    RCLCPP_ERROR(this->get_logger(), "客户端节点已关闭.");
                    return;
                }
                RCLCPP_INFO(this->get_logger(), "等待服务端节点启动...");
            }
            auto request = std::make_shared<example_interfaces::srv::AddTwoInts::Request>();
            request->a = printf("请输入第一个整数: ");
            request->b = printf("请输入第一个整数");
            auto result_future = add_ints_server_->async_send_request(request);
            try {
                auto result = result_future.get();
                RCLCPP_INFO(this->get_logger(), "请求结果: %ld", result->sum);
            } catch (const std::exception &e) {
                RCLCPP_ERROR(this->get_logger(), "服务调用失败: %s", e.what());
            }
        }).detach();
        
    }
private:
// 创建客户端对象
rclcpp::Client<example_interfaces::srv::AddTwoInts>::SharedPtr add_ints_server_;
};
// 主函数
int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    // 创建指针共享对象
    auto node = std::make_shared<ServiceClient01>("service_client_01");
    // 进入循环，等待服务请求
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
